function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let drone;
let plants = [];
let clouds = [];
let birds = [];
let battery = 100;
let score = 0;
let gameState = "start"; // start, playing, gameover

function setup() {
  createCanvas(800, 600);
  drone = new Drone();
  
  // Cria plantas iniciais
  for (let i = 0; i < 20; i++) {
    plants.push(new Plant());
  }
  
  // Cria nuvens (obstáculos)
  for (let i = 0; i < 5; i++) {
    clouds.push(new Cloud());
  }
  
  // Cria pássaros (obstáculos)
  for (let i = 0; i < 3; i++) {
    birds.push(new Bird());
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  
  // Tela inicial
  if (gameState === "start") {
    drawStartScreen();
  } 
  // Jogo rodando
  else if (gameState === "playing") {
    drawField();
    updateGame();
  } 
  // Game Over
  else if (gameState === "gameover") {
    drawGameOver();
  }
}

function keyPressed() {
  if (gameState === "start" && key === " ") {
    gameState = "playing";
  } else if (gameState === "gameover" && key === " ") {
    resetGame();
    gameState = "playing";
  }
}

function drawStartScreen() {
  fill(0);
  textSize(32);
  textAlign(CENTER);
  text("DRONE AGRÍCOLA TECNO", width / 2, height / 3);
  textSize(20);
  text("Pressione ESPAÇO para começar", width / 2, height / 2);
  textSize(16);
  text("Use SETAS para mover o drone", width / 2, height / 2 + 50);
  text("Plante (BARRA DE ESPAÇO) e evite pássaros!", width / 2, height / 2 + 80);
}

function drawGameOver() {
  fill(0);
  textSize(32);
  textAlign(CENTER);
  text("FIM DE JOGO", width / 2, height / 3);
  textSize(20);
  text(`Pontuação: ${score}`, width / 2, height / 2);
  text("Pressione ESPAÇO para recomeçar", width / 2, height / 2 + 50);
}

function drawField() {
  // Desenha o campo (grama)
  fill(34, 139, 34);
  rect(0, height - 100, width, 100);
  
  // Desenha plantas
  for (let plant of plants) {
    plant.show();
  }
  
  // Desenha nuvens
  for (let cloud of clouds) {
    cloud.show();
    cloud.move();
  }
  
  // Desenha pássaros
  for (let bird of birds) {
    bird.show();
    bird.move();
    if (bird.hits(drone)) {
      battery -= 5; // Perde bateria se atingido
    }
  }
  
  // Desenha drone
  drone.show();
  drone.move();
  
  // Mostra HUD (bateria e pontuação)
  fill(0);
  textSize(16);
  text(`Bateria: ${battery}%`, 50, 30);
  text(`Pontuação: ${score}`, 50, 60);
  
  // Verifica se a bateria acabou
  if (battery <= 0) {
    gameState = "gameover";
  }
}

function updateGame() {
  // Gera novas plantas aleatórias
  if (frameCount % 60 === 0 && random() < 0.3) {
    plants.push(new Plant());
  }
  
  // Recarrega bateria lentamente (se não estiver movendo)
  if (!drone.isMoving && battery < 100) {
    battery += 0.05;
  }
  
  // Diminui bateria ao se mover
  if (drone.isMoving) {
    battery -= 0.1;
  }
}

function resetGame() {
  battery = 100;
  score = 0;
  plants = [];
  birds = [];
  clouds = [];
  drone = new Drone();
  
  for (let i = 0; i < 20; i++) plants.push(new Plant());
  for (let i = 0; i < 5; i++) clouds.push(new Cloud());
  for (let i = 0; i < 3; i++) birds.push(new Bird());
}

// Classes do jogo
class Drone {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.speed = 5;
    this.isMoving = false;
  }
  
  move() {
    this.isMoving = false;
    
    if (keyIsDown(LEFT_ARROW) && this.x > 30) {
      this.x -= this.speed;
      this.isMoving = true;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - 30) {
      this.x += this.speed;
      this.isMoving = true;
    }
    if (keyIsDown(UP_ARROW) && this.y > 30) {
      this.y -= this.speed;
      this.isMoving = true;
    }
    if (keyIsDown(DOWN_ARROW) && this.y < height - 30) {
      this.y += this.speed;
      this.isMoving = true;
    }
    
    // Plantar sementes (barra de espaço)
    if (keyIsDown(32)) {
      this.plantSeed();
    }
  }
  
  plantSeed() {
    plants.push(new Plant(this.x, this.y + 30));
    score += 10;
  }
  
  show() {
    fill(50);
    ellipse(this.x, this.y, 40, 20); // Corpo do drone
    fill(200);
    rect(this.x - 30, this.y - 15, 60, 5); // Asas
  }
}

class Plant {
  constructor(x, y) {
    this.x = x || random(width);
    this.y = y || height - 90;
    this.size = random(10, 30);
  }
  
  show() {
    fill(0, 100, 0);
    rect(this.x, this.y, 5, -this.size); // Caule
    fill(50, 200, 50);
    ellipse(this.x, this.y - this.size, 15, 10); // Folhas
  }
}

class Cloud {
  constructor() {
    this.x = random(width);
    this.y = random(50, 200);
    this.speed = random(1, 3);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width + 50) this.x = -50;
  }
  
  show() {
    fill(255, 255, 255, 200);
    ellipse(this.x, this.y, 60, 40);
    ellipse(this.x + 30, this.y, 70, 50);
  }
}

class Bird {
  constructor() {
    this.x = random(width);
    this.y = random(100, 400);
    this.speed = random(2, 4);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width + 20) {
      this.x = -20;
      this.y = random(100, 400);
    }
  }
  
  show() {
    fill(139, 69, 19); // Marrom
    ellipse(this.x, this.y, 20, 10); // Corpo
    triangle(this.x + 10, this.y, this.x + 20, this.y - 5, this.x + 20, this.y + 5); // Bico
  }
  
  hits(drone) {
    let d = dist(this.x, this.y, drone.x, drone.y);
    return d < 30;
  }
}